//
// Created by Jon on 12/6/2020.
//

#ifndef INC_2020HW4STARTER_SEARCH_H
#define INC_2020HW4STARTER_SEARCH_H


#include "House.h"


void searchForTreasure(House house, Search *search);

float countTreasure(House house, Search search);


#endif //INC_2020HW4STARTER_SEARCH_H
