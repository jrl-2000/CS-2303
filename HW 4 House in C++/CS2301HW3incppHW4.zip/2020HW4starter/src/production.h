/*
 * Production.h
 *
 *  Created on: December 6th, 2020
 *      Author: Jonathan Lopez
 */

#ifndef PRODUCTION_H_
#define PRODUCTION_H_
#include <stdio.h>
#include <stdbool.h>
#include "Search.h"

bool production(int argc, char* argv[]);

#endif /* PRODUCTION_H_ */
