//
// Created by Jon on 10/28/2020.
//

#ifndef HW1F_HOUSE_H
#define HW1F_HOUSE_H

#endif //HW1F_HOUSE_H

#include "Room.h"

typedef struct {
    int nRooms;
    Room** theRoomPs;
}House;
int getNumberOfRoooms(House*);

#endif /* HW1F_HOUSE_H_*/



