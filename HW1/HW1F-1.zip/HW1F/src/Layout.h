//
// Created by Jon on 10/28/2020.
//
#include "Room.h"
#ifndef HW1F_LAYOUT_H
#define HW1F_LAYOUT_H

#endif //HW1F_LAYOUT_H
typedef struct {

}Layout;
int countRooms(Layout*);
Room* getFirstRoom(Layout*);
Room*isOk(Room*);
