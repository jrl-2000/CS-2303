//
// Created by Jon on 10/28/2020.
//

#ifndef HW1F_ROOM_H
#define HW1F_ROOM_H
#include <stdio.h>
#include <stdbool.h>

#endif //HW1F_ROOM_H
typedef struct {

}Room;
bool isOpen(Room*);
bool haveTreasure(Room*);

