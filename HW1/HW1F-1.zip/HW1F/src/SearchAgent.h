//
// Created by Jon on 10/28/2020.
//
#include "House.h"

#ifndef HW1F_SEARCHAGENT_H
#define HW1F_SEARCHAGENT_H

#endif //HW1F_SEARCHAGENT_H
typedef struct {

}SearchAgent;

Room* getnewRoom(House*);


