/*
 * space.h
 *
 *  Created on: Jan 27, 2020
 *      Author: Jonathan Lopez
 */

#ifndef SPACE_H_
#define SPACE_H_

#include <stdbool.h>



void printBoard(int*, int);
bool initSpace(int*, int);

#endif /* SPACE_H_ */
