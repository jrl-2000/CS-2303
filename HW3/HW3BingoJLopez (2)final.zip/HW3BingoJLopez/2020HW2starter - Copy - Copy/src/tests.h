/*
 * tests.h
 *
 *  Created on: Jul 4, 2019
 *      Author: Jonathan Lopez
 */

#ifndef TESTS_H_
#define TESTS_H_


#include "production.h"
#include "space.h"
#include "marker.h"
bool tests();
bool testPrintBingoBoard();
bool callsOnSpace();
bool testPrintHistory();







#endif /* TESTS_H_ */
