/*
 * Production.h
 *
 *  Created on: Feb 1, 2020
 *      Author: Jon
 */

#ifndef PRODUCTION_H_
#define PRODUCTION_H_

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include "gameplay.h"

bool production(int argc, char* argv[]);

#endif /* PRODUCTION_H_ */
