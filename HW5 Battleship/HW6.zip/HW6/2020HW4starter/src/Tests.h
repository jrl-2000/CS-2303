/*
 * Tests.h
 *
 *  Created on: Feb 1, 2020
 *      Author: Jon
 */

#ifndef TESTS_H_
#define TESTS_H_

#include "gameboard.h"
bool tests();
bool printBoard();
bool printBoard1();
bool shotTest();
bool randPlaceTest();
#endif /* TESTS_H_ */
