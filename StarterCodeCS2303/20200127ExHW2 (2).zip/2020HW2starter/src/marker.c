/*
 * marker.c
 *
 *  Created on: Jan 27, 2020
 *      Author: Therese
 */

#include "marker.h"

Marker* placeMarker(int r, int c)
{
	Marker* mP = (Marker*) malloc (sizeof(Marker));
	//TODO what do we do?

	return mP;
}
