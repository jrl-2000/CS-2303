/*
 * tests.c
 *
 *  Created on: Jul 4, 2019
 *      Author: Therese
 */

#include "tests.h"
#include "production.h"

bool tests()
{
	bool answer = false;
	bool ok1 =  test1();
	answer = ok1;
	return answer;
}

bool test1()
{
	bool ok = true;


	return ok;
}
