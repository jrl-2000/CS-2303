/*
 * tests.c
 *
 *  Created on: Sep 11, 2019
 *      Author: Therese
 */


#include "tests.h"

#include <stdio.h>


bool tests()
{
	bool answer = true;




	return answer;
}

