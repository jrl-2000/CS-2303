/*
 * tests.h
 *
 *  Created on: Sep 11, 2019
 *      Author: Therese
 */

#ifndef TESTS_H_
#define TESTS_H_
#include <stdbool.h>

bool tests();


#endif /* TESTS_H_ */
