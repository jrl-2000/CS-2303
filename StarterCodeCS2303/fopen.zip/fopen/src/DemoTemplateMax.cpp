/*
 * DemoTemplateMax.cpp
 *
 *  Created on: Sep 5, 2019
 *      Author: Therese
 */

#include "DemoTemplateMax.h"

DemoTemplateMax::DemoTemplateMax() {
	// TODO Auto-generated constructor stub

}

DemoTemplateMax::~DemoTemplateMax() {
	// TODO Auto-generated destructor stub
}

