/*
 * Tree.c
 *
 *  Created on: Sep 5, 2019
 *      Author: Therese
 */

#include "Tree.h"

TreeNode* makeEmptyTree()
{
	TreeNode* t_P = (TreeNode*) malloc (sizeof(TreeNode));

	t_P->parent = (struct TreeNode*) 0; //this is the root
	t_P->leftChild = (struct TreeNode*) 0;
	t_P->rightChild = (struct TreeNode*) 0;
	t_P->p = (TPayload*) 0; //zero for the root
	return t_P;
}
TreeNode* makeSingletonTree()
{
	TreeNode* t_P = makeEmptyTree();
	TPayload* pP = (TPayload*) malloc (sizeof(TPayload));
	t_P->p = (TPayload*) pP; //
	t_P->p->x = 0; //the payload x variable is 0
	return t_P;
}


int growTree(TreeNode* n, ChildHand c)
{
	int nodeValue = -1;
	TreeNode* np = makeSingletonTree();

	if(c==Left)
	{
		nodeValue = n->p->x +1;
		n->leftChild = (struct TreeNode*) np;
	}
	else
	{
		nodeValue = n->p->x +2;
		n->rightChild = (struct TreeNode*) np;
	}
	np->p->x = nodeValue;
	return nodeValue;
}


