/*
 * Tree.h
 *
 *  Created on: Sep 5, 2019
 *      Author: Therese
 */

#ifndef TREE_H_
#define TREE_H_

#include <stdlib.h> //for malloc

typedef struct
{
	int x;
	double y; //just an arbitrary payload
}TPayload;

typedef struct
{
    TPayload* p;
    struct TreeNode* parent;
    struct TreeNode* leftChild;
    struct TreeNode* rightChild;
}TreeNode;

typedef enum
{
	Left,
	Right
}ChildHand;



TreeNode* makeEmptyTree();
TreeNode* makeSingletonTree();
int growTree(TreeNode* n, ChildHand c);

#endif /* TREE_H_ */
