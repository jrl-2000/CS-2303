/*
 * ll.c
 *
 *  Created on: Sep 11, 2019
 *      Author: Therese
 */

#include "ll.h"
#include <stdlib.h> //for malloc

LLNode* makeEmptyList()
{
	LLNode* mt_P =
			(LLNode*) malloc(sizeof(LLNode));
	mt_P->next=(struct LLNode*)0;
	mt_P->prev=(struct LLNode*)0;
	mt_P->p=(Payload*)0;
	return mt_P;
}

LLNode* makeSingletonList(Payload* pay)
{
	LLNode* mt_P = makeEmptyList();
	mt_P->p=pay;
	return mt_P;
}

LLNode* growList(LLNode* h, Payload* pay)
{
	LLNode* bead_P = makeSingletonList(pay);
	while(h->next!= (struct LLNode*)0)
	{
		h=(LLNode*)h->next;
	}
	//now h is the last node
	h->next = (struct LLNode*) bead_P;
	return bead_P;
}
