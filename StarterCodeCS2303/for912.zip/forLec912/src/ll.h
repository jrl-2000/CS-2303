/*
 * ll.h
 *
 *  Created on: Sep 11, 2019
 *      Author: Therese
 */

#ifndef LL_H_
#define LL_H_

	typedef struct
	{
	    double red; //these three need to be restricted to the closed interval on real line [0,1]
	    double green;
	    double blue;
	}Payload;

	typedef struct
	{
	    Payload* p;
	    struct LLNode* prev;
	    struct LLNode* next;
	}LLNode;

	LLNode* makeEmptyList();
	LLNode* makeSingletonList(Payload* pay);
	LLNode* growList(LLNode* h, Payload* pay);


#endif /* LL_H_ */
