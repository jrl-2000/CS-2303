/*
 * tests.c
 *
 *  Created on: Sep 11, 2019
 *      Author: Therese
 */


#include "tests.h"
#include "ll.h"
#include <stdio.h>
#include "Tree.h"

bool tests()
{
	bool answer = false;

	bool ok1 = testLL();
	answer = ok1;

	return answer;
}

bool testLL()
{
	bool ok = false;

	bool ok1 = testMakeEmptyList();
	bool ok2 = testMakeSingletonList();
	bool ok3 = testGrowList();
	bool ok4 = testRemoveFromList();

	ok=ok1&&ok2&&ok3&&ok4;
	return ok;
}

bool testMakeEmptyList()
{
	bool ans = false;

	LLNode* mtll = makeEmptyList();
	bool ok1 = mtll->next == (struct LLNode*)0;
	bool ok2 = mtll->prev == (struct LLNode*)0;
	bool ok3 = mtll->p == (Payload*)0;
	ans = ok1 && ok2 && ok3;
	if(ans)
	{
		puts("makeEmptyList worked.");
	}
	return ans;
}

bool testMakeSingletonList()
{
	bool ans = false;
	Payload theP;
	theP.red = 3;
	theP.green = 4.5;
	LLNode* mtll = makeSingletonList(&theP);
	bool ok1 = mtll->next == (struct LLNode*)0;
	bool ok2 = mtll->prev == (struct LLNode*)0;
	bool ok3 = mtll->p == &theP;
	ans = ok1 && ok2 && ok3;
	if(ans)
	{
		puts("makeSingletonList worked.");
	}

	return ans;
}

bool testGrowList()
{
	bool ans = false;
	//make a singleton list
	Payload theP;
	theP.red = 3;
	theP.green = 4.5;
	LLNode* mtll = makeSingletonList(&theP);
	//extend it with another node, new payload
	Payload the2P;
	the2P.red = 5.2;
	the2P.blue = 3.14;
	LLNode* grown_P = growList(mtll, &the2P);
	LLNode* second_P = (LLNode*) mtll->next;
	Payload* nextPay_P = second_P->p;
	if(second_P == grown_P && nextPay_P->red == 5.2 && nextPay_P->blue == 3.14 && mtll->p->red == 3 && mtll->p->green == 4.5)
	{
		ans = true;
		puts("Extend list worked.");
	}

	return ans;
}

bool testRemoveFromList()
{
	bool ans = false;
	return ans;
}


bool testTree()
{
	bool ok1 = testMakeEmptyTree();
	bool ok2 = testMakeSingletonTree();
	bool ok3 = testGrowTree();
	bool ok4 = testBuildingTree();
	return ok1&&ok2&&ok3&&ok4;
}
bool testMakeEmptyTree()
{
	bool answer = false;

	TreeNode* np = makeEmptyTree();
	if(((np->leftChild) == (struct TreeNode*) 0) &&
			((np->rightChild) == (struct TreeNode*) 0) &&
			((np->parent) == (struct TreeNode*) 0) &&
			((np->p) == (TPayload*) 0))
	{
		answer = true;
	}
	puts("Ran testMakeEmptyTree");
	fflush(stdout);
	return answer;
}





bool testMakeSingletonTree()
{
	bool answer = false;
	TreeNode* np = makeSingletonTree();
	if((np->p->x) ==0)

	{
		answer = true;
	}
	puts("Ran testMakeSingletonTree");
	fflush(stdout);
	return answer;
}

bool testGrowTree()
{
	bool answer = false;
	TreeNode* np = makeSingletonTree();
	int g = growTree(np, Left);
	if(g ==1)
	{
		answer = true;
	}
	puts("Ran testGrowTree");
	fflush(stdout);
	g = growTree(np, Right);
	if (g!=2)
	{
		answer = false;
	}
	return answer;
}

bool testBuildingTree()
{
	bool answer = false;
	TreeNode* t = makeSingletonTree();
	int g1 = growTree(t, Left);
	int g2 = growTree(t, Right);
	int g3 = growTree((TreeNode*)(t->leftChild), Left);
	int g4 = growTree((TreeNode*)(t->leftChild), Right);
	TreeNode* t1 = (TreeNode*) (t->leftChild);
	int g5 = growTree((TreeNode*)(t1->leftChild), Left);
	int g6 = growTree((TreeNode*)(t1->leftChild),Right);
	printf("  %d %d %d %d %d %d\n", g1, g2,g3,g4,g5,g6);
	fflush(stdout);
	answer= true;
	return answer;
}


