/*
 * tests.h
 *
 *  Created on: Sep 11, 2019
 *      Author: Therese
 */

#ifndef TESTS_H_
#define TESTS_H_
#include <stdbool.h>

bool tests();
bool testLL();
bool testTree();
bool testMakeEmptyList();
bool testMakeSingletonList();
bool testGrowList();
bool testRemoveFromList();
bool testMakeEmptyTree();
bool  testMakeSingletonTree();
bool  testGrowTree();
bool  testBuildingTree();


#endif /* TESTS_H_ */
