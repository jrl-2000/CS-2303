/*
 * DemoTemplateMax.h
 *
 *  Created on: Sep 5, 2019
 *      Author: Therese
 */

#ifndef DEMOTEMPLATEMAX_H_
#define DEMOTEMPLATEMAX_H_

class DemoTemplateMax {
public:
	DemoTemplateMax();
	virtual ~DemoTemplateMax();
};

#endif /* DEMOTEMPLATEMAX_H_ */
