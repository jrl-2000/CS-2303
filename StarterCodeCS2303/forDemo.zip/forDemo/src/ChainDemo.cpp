/*
 * ChainDemo.cpp
 *
 *  Created on: Sep 22, 2019
 *      Author: Therese
 */

#include "ChainDemo.h"

ChainDemo::ChainDemo() {
	// TODO Auto-generated constructor stub

}

ChainDemo::~ChainDemo() {
	// TODO Auto-generated destructor stub
}

ChainDemo* ChainDemo::color()
{
	return this;
}
ChainDemo* ChainDemo::visibility()
{
	return this;
}

