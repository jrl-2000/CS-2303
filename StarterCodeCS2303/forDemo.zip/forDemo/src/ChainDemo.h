/*
 * ChainDemo.h
 *
 *  Created on: Sep 22, 2019
 *      Author: Therese
 */

#ifndef CHAINDEMO_H_
#define CHAINDEMO_H_

class ChainDemo {
public:
	ChainDemo();
	ChainDemo* color();
	ChainDemo* visibility();
	virtual ~ChainDemo();
};

#endif /* CHAINDEMO_H_ */
