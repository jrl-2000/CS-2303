/*
 * CommandLine.cpp
 *
 *  Created on: Sep 21, 2019
 *      Author: Therese
 */

#include "CommandLine.h"


CommandLine::CommandLine() {
	// TODO Auto-generated constructor stub

}

CommandLine::~CommandLine() {
	// TODO Auto-generated destructor stub
}

void CommandLine::setDirectoryName(char* dn)
{
	directoryName = dn;
}
string CommandLine::getDirectoryName()
{

	return  directoryName;
}

