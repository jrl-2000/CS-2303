/*
 * CommandLine.h
 *
 *  Created on: Sep 21, 2019
 *      Author: Therese
 */

#ifndef COMMANDLINE_H_
#define COMMANDLINE_H_

#include <iostream>
#include <bits/stdc++.h>
using namespace std;

class CommandLine {
public:
	CommandLine();
	string getDirectoryName();
	void setDirectoryName(char* dn);
	virtual ~CommandLine();
private:
	string directoryName;
};

#endif /* COMMANDLINE_H_ */
