/*
 * DirectoryListing.cpp
 *
 *  Created on: Sep 21, 2019
 *      Author: Therese
 */

#include "DirectoryListing.h"

DirectoryListing::DirectoryListing() {
	// TODO Auto-generated constructor stub

}

DirectoryListing::~DirectoryListing() {
	// TODO Auto-generated destructor stub
}

