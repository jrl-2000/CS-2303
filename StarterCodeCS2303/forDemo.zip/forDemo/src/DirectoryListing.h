/*
 * DirectoryListing.h
 *
 *  Created on: Sep 21, 2019
 *      Author: Therese
 */

#ifndef DIRECTORYLISTING_H_
#define DIRECTORYLISTING_H_

class DirectoryListing {
public:
	DirectoryListing();
	virtual ~DirectoryListing();
};

#endif /* DIRECTORYLISTING_H_ */
