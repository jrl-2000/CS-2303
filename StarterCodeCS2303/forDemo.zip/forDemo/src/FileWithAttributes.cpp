/*
 * FileWithAttributes.cpp
 *
 *  Created on: Sep 21, 2019
 *      Author: Therese
 */

#include "FileWithAttributes.h"

FileWithAttributes::FileWithAttributes() {
	aP = (Attributes*) 0;

}

FileWithAttributes::FileWithAttributes(Attributes* aP) {

	setAP(aP);
}

int FileWithAttributes::getDay()
{
	return aP->dP->day;
}
int FileWithAttributes::getMonth()
{
	return aP->dP->month;
}
int FileWithAttributes::getYear()
{
	return aP->dP->year;
}
int FileWithAttributes::getMinute()
{
	return aP->tP->min;
}
int FileWithAttributes::getHour()
{
	return aP->tP->hour;
}
bool FileWithAttributes::getAMPM()
{
	return aP->tP->isAM;
}
char* FileWithAttributes::getFilename()
{
	return aP->filename;
}
bool FileWithAttributes::getIsDir()
{
	return aP->isDir;
}
void FileWithAttributes::setDay(int d)
{
	aP->dP->day=d;
}
void FileWithAttributes::setMonth(int m)
{
	aP->dP->month=m;
}
void FileWithAttributes::setYear(int y)
{

	aP->dP->year=y;
}

void FileWithAttributes::setMinute(int m)
{
	aP->tP->min=m;
}
void FileWithAttributes::setHour(int h)
{
	aP->tP->hour=h;
}
void FileWithAttributes::setAMPM(bool b)
{
	aP->tP->isAM=b;
}

void FileWithAttributes::setFilename(char* cP)
{
	 aP->filename=cP;
}
void FileWithAttributes::setIsDir(bool b)
{
	aP->isDir=b;
}

void FileWithAttributes::setAP(Attributes* a)
{
	aP = a;
}

FileWithAttributes::~FileWithAttributes() {
	// TODO Auto-generated destructor stub
}

