/*
 * FileWithAttributes.h
 *
 *  Created on: Sep 21, 2019
 *      Author: Therese
 */

#ifndef FILEWITHATTRIBUTES_H_
#define FILEWITHATTRIBUTES_H_

typedef struct
{
	int month;
	int day;
	int year;
}FDate;

typedef struct
{
	int hour;
	int min;
	bool isAM;
}FTime;

typedef struct
{
	FDate* dP;
	FTime* tP;
	bool isDir;
	char* filename;
}Attributes;

class FileWithAttributes {
public:
	FileWithAttributes();
	FileWithAttributes(Attributes* aP);
	int getDay();
	int getMonth();
	int getYear();
	int getMinute();
	int getHour();
	bool getAMPM();
	char* getFilename();
	bool getIsDir();
	void setDay(int);
	void setMonth(int);
	void setYear(int);
	void setMinute(int);
	void setHour(int);
	void setAMPM(bool);
	void setAP(Attributes* a);
	void setFilename(char*);
	void setIsDir(bool);

	virtual ~FileWithAttributes();

private:
	Attributes* aP;

};

#endif /* FILEWITHATTRIBUTES_H_ */
