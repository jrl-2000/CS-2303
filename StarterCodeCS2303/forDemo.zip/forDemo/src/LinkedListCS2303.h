/*
 * LinkedListCS2303.h
 *
 *  Created on: Sep 6, 2019
 *      Author: Therese
 */

#ifndef LINKEDLISTCS2303_H_
#define LINKEDLISTCS2303_H_
#include <iostream>

using namespace std;
#include "FileWithAttributes.h"

typedef struct
{
	int first;
	int second;
}Payload;

typedef struct
{
	FileWithAttributes* fP;
}Payload2;

struct LLNode
{
	Payload2* payP;
	LLNode* next;
	LLNode* previous;
};



class LinkedListCS2303 {

private:
	LLNode* head; //list is null or node followed by list;

public:
	LinkedListCS2303();
	LLNode* makeSingletonList(Payload2* pay);
	LLNode* growList(Payload2* pay);
	LLNode* getNext();
	LLNode* getPrev();
	Payload2* getPay();
	LLNode* getHead();
	void setNext(LLNode* n);
	void setPrev(LLNode* p);
	void setPay(Payload2* p);
	void setHead(LLNode* h);
	virtual ~LinkedListCS2303();
};



#endif /* LINKEDLISTCS2303_H_ */
