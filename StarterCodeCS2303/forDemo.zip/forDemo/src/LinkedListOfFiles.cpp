/*
 * LinkedListOfFiles.cpp
 *
 *  Created on: Sep 21, 2019
 *      Author: Therese
 */

#include "LinkedListOfFiles.h"

LinkedListOfFiles::LinkedListOfFiles() {
	// TODO Auto-generated constructor stub

}

LinkedListOfFiles::~LinkedListOfFiles() {
	// TODO Auto-generated destructor stub
}

