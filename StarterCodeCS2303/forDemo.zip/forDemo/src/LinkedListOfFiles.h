/*
 * LinkedListOfFiles.h
 *
 *  Created on: Sep 21, 2019
 *      Author: Therese
 */

#ifndef LINKEDLISTOFFILES_H_
#define LINKEDLISTOFFILES_H_

class LinkedListOfFiles {
public:
	LinkedListOfFiles();
	virtual ~LinkedListOfFiles();
};

#endif /* LINKEDLISTOFFILES_H_ */
