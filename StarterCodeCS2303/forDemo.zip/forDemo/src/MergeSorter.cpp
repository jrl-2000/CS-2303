/*
 * MergeSorter.cpp
 *
 *  Created on: Sep 21, 2019
 *      Author: Therese
 */

#include "MergeSorter.h"

MergeSorter::MergeSorter() {
	// TODO Auto-generated constructor stub

}

MergeSorter::~MergeSorter() {
	// TODO Auto-generated destructor stub
}

