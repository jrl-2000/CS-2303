/*
 * MergeSorter.h
 *
 *  Created on: Sep 21, 2019
 *      Author: Therese
 */

#ifndef MERGESORTER_H_
#define MERGESORTER_H_

class MergeSorter {
public:
	MergeSorter();
	virtual ~MergeSorter();
};

#endif /* MERGESORTER_H_ */
