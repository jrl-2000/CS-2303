/*
 * Production.cpp
 *
 *  Created on: Sep 5, 2019
 *      Author: Therese
 */

#include "Production.h"
#include <iostream>
#include <string.h>
using namespace std;

Production::Production() {
	// TODO Auto-generated constructor stub

}

Production::~Production() {
	// TODO Auto-generated destructor stub
}

bool Production::production(int argc, char* argv[])
{
	bool answer = false;
	if(argc <=1) //no interesting information
	{
		puts("Didn't find any arguments.");
		fflush(stdout);
		answer = false;
	}
	else //there is interesting information
	{
		printf("Found %d arguments.\n", argc);
		fflush(stdout);
		char filename[FILENAMELENGTHALLOWANCE];
		char attribute[FILENAMELENGTHALLOWANCE];
		char *eptr;
		for(int i = 1; i<argc; i++) //don't want to read argv[0]
		{//argv[i] is a string
			//in this program our arguments are NR, NC, gens, filename, print and pause
			//because pause is optional, argc could be 6 or 7
			//because print is optional (if print is not present, neither is pause) argc could be 5
			switch(i)
			{
			case 1:
				//this is filename
				printf("The length of the filename is %d.\n",strlen(argv[i]));
				printf("The proposed filename is %s.\n", argv[i]);
				if(strlen(argv[i])>=FILENAMELENGTHALLOWANCE)
				{
					puts("Filename is too long.");
					fflush(stdout);
					answer = false;
				}
				else
				{
					strcpy(filename, argv[i]);
					printf("Filename was %s.\n", filename);
					fflush(stdout);
				}
				break;
			case 2:
				//this is attribute name
				printf("The length of the attribute name is %d.\n",strlen(argv[i]));
				printf("The proposed attribute name is %s.\n", argv[i]);
				if(strlen(argv[i])>=FILENAMELENGTHALLOWANCE)
				{
					puts("Attribute name is too long.");
					fflush(stdout);
					answer = false;
				}
				else
				{
					strcpy(filename, argv[i]);
					printf("Attribute name was %s.\n", filename);
					fflush(stdout);
				}
				break;

			default:
				puts("Unexpected argument count.");
				fflush(stdout);
				answer = false;
				break;
			}
		}
	}

	cout << "in production" << endl;
	return answer;
}
