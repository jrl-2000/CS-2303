/*
 * Tests.cpp
 *
 *  Created on: Sep 5, 2019
 *      Author: Therese
 */

#include "Tests.h"
#include "Production.h"
#include "StackTemplate.h"
#include "LinkedListCS2303.h"
#include <iostream>
#include "FileWithAttributes.h"
#include "ChainDemo.h"
using namespace std;

Tests::Tests() {
	// TODO Auto-generated constructor stub

}

Tests::~Tests() {
	// TODO Auto-generated destructor stub
}

bool Tests::tests(){
	bool answer = true;

	bool ok1 = testEmptyList();
	cout << "Back from test empty list: " <<ok1<< endl; fflush(stdout);
	bool ok2 = testSingletonList();
	cout << "Back from test singleton list: "<<ok2 << endl;fflush(stdout);
	bool ok3 = testAddNode();
	cout << "Back from test add to list: " <<ok3<< endl;fflush(stdout);
	bool ok4 = testDeleteList();
	cout << "Back from test delete: "<<ok4 << endl;fflush(stdout);

	bool ok5 = testGetFilesFromDirectory();
	cout << "Back from test get files from directory: "<<ok5 << endl;fflush(stdout);
	bool ok10 = testMakeFileWithAttributes();
	cout << "Back from test make file with attributes: "<<ok10 << endl;fflush(stdout);
	bool ok12 = testDisplayFileNamesFromLinkedList();
	cout << "Back from test list files from linked list: "<<ok12 << endl;fflush(stdout);
	//bool ok6 =  testDesignateAttribute();
	//cout << "Back from test designate attribute" << endl;fflush(stdout);
	//bool ok7 = testSortOnDesignatedAttribute();
	//bool ok8 =testIdentifyViewableAttribute();
	//bool ok9=testDisplayList();
	//bool ok11 = testGetFilesFromListingFile();

	ChainDemo* cd = new ChainDemo();
	cd->color()->visibility();


	answer = ok1 && ok2 && ok3 && ok4 && ok5 &&/* ok6 && ok7 && ok8 && ok9 &&*/ ok10 && /*ok11 &&*/ok12;

	return answer;
}

bool Tests::testEmptyList()
{
	bool ok = true;
	LinkedListCS2303* ll_P = new LinkedListCS2303();
	if(ll_P->getNext() !=(LLNode*)0)
	{
		ok = false;
	}
	if(ll_P->getPrev() != (LLNode*)0)
	{
		ok = false;
	}
	if(ll_P->getPay() != (Payload2*)0)
	{
		ok = false;
	}
	return ok;
}
bool Tests::testSingletonList()
{
	bool ok = true;

	LinkedListCS2303* ll_P = new LinkedListCS2303();//make the empty list
	if(!ll_P->getHead())//this is supposed to be an LLNode*
	{
		cout<<"can get head"<<endl; fflush(stdout);
	}
	Payload2* payP1 = (Payload2*) malloc(sizeof(Payload2));//make the payload
	ll_P->makeSingletonList(payP1);//make the singleton list
	if(ll_P->getHead()->payP)
	{
		cout<<"can get first payload"<<endl; fflush(stdout);
	}
	FileWithAttributes* theFileP = (FileWithAttributes*)malloc(sizeof(FileWithAttributes));
	Attributes* theAttributesP = (Attributes*) malloc(sizeof(Attributes));
	//make the payload(pointer to file with attributes) point to the file with attributes
	//payload points to file-w-A
	payP1->fP = theFileP;
	if(ll_P->getHead()->payP->fP)
	{
		cout<<"can get file pointer"<<endl; fflush(stdout);
	}
	//make the file with attributes point to its attributes
	payP1->fP->setAP(theAttributesP);


	//establish some attributes
	char fname[] = "file1";
	payP1->fP->setFilename(fname);
	payP1->fP->setIsDir(false);
	//make the date and time parts
	FDate* dP = (FDate*)malloc(sizeof(FDate));
	FTime* tP = (FTime*)malloc(sizeof(FTime));
	theAttributesP->dP = dP;
	theAttributesP->tP = tP;
	dP->day = 21;
	dP->month = 9;
	dP->year = 2019;
	tP->hour = 3;
	tP->min=23;
	tP->isAM=false;
	cout << "set the values for the singleton list"<<endl; fflush(stdout);

	if(ll_P->getHead()->payP->fP->getDay()!=21)
	{
		ok = false;
	}

	cout << "read a value from the singleton list"<<endl; fflush(stdout);
	return ok;
}

bool Tests::testAddNode()
{
	bool ok = true;
	LinkedListCS2303* ll_P1 = new LinkedListCS2303();
	FileWithAttributes* theFileP = (FileWithAttributes*)malloc(sizeof(FileWithAttributes));
	Payload2* payP1 = (Payload2*) malloc(sizeof(Payload2));
	//payload points to file
	Attributes* theAttributesP = (Attributes*) malloc(sizeof(Attributes));
	//make the payload(pointer to file with attributes) point to the file with attributes
	payP1->fP = theFileP;
	//make the file with attributes point to its attributes
	payP1->fP->setAP(theAttributesP);
	//establish some attributes
	char fname[] = "file2";
	payP1->fP->setFilename(fname);
	payP1->fP->setIsDir(false);
	//make the date and time parts
	FDate* dP = (FDate*)malloc(sizeof(FDate));
	FTime* tP = (FTime*)malloc(sizeof(FTime));
	theAttributesP->dP = dP;
	theAttributesP->tP = tP;
	dP->day = 21;
	dP->month = 9;
	dP->year = 2019;
	tP->hour = 3;
	tP->min=23;
	tP->isAM=false;

	ll_P1->makeSingletonList(payP1);//first list item
	FileWithAttributes* theFileP2 = (FileWithAttributes*)malloc(sizeof(FileWithAttributes));
	Payload2* payP2 = (Payload2*) malloc(sizeof(Payload2));
	Attributes* theAttributesP2 = (Attributes*) malloc(sizeof(Attributes));
	//make the payload(pointer to file with attributes) point to the file with attributes
	payP2->fP = theFileP2;
	//make the file with attributes point to its attributes
	payP2->fP->setAP(theAttributesP2);
	//establish some attributes
	char fname2[] = "file2";
	payP2->fP->setFilename(fname2);
	payP2->fP->setIsDir(false);
	//make the date and time parts
	FDate* dP2 = (FDate*)malloc(sizeof(FDate));
	FTime* tP2 = (FTime*)malloc(sizeof(FTime));
	theAttributesP2->dP = dP2;
	theAttributesP2->tP = tP2;
	dP2->day = 2;
	dP2->month = 2;
	dP2->year = 2019;
	tP2->hour = 3;
	tP2->min=23;
	tP2->isAM=false;
	LLNode* retP = ll_P1->growList(payP2);//second list item, 0 traversals
	cout << "Back from growList with "<<retP << endl; fflush(stdout);
	cout << "Get next is " << ll_P1->getNext() <<endl; fflush(stdout);
	cout << ll_P1->getNext()->payP <<endl; fflush(stdout);

	if(ll_P1->getNext()->payP != payP2)
	{
		ok = false;
	}
	cout << "Back from adding payload" << endl; fflush(stdout);
	if(ll_P1->getNext()->payP->fP->getYear() != 2019)
	{
		ok = false;
	}
	FileWithAttributes* theFileP3 = (FileWithAttributes*)malloc(sizeof(FileWithAttributes));
	Attributes* theAttributesP3 = (Attributes*) malloc(sizeof(Attributes));
	Payload2* payP3 = (Payload2*) malloc(sizeof(Payload2));
	payP3->fP = theFileP3;
	//make the file with attributes point to its attributes
	payP3->fP->setAP(theAttributesP3);
	FDate* dP3 = (FDate*)malloc(sizeof(FDate));
	FTime* tP3 = (FTime*)malloc(sizeof(FTime));
	theAttributesP3->dP = dP3;
	theAttributesP3->tP = tP3;
	dP3->day = 20;
	dP3->month = 10;
	dP3->year = 2019;

	LLNode* ret2P = ll_P1->growList(payP3);//third list item 1 traversal
	if(ll_P1->getNext()->next->payP->fP->getMonth() != 10)
	{
		ok = false;
	}


	return ok;
}

bool Tests::testDeleteList()
{
	bool ok = true;
	LinkedListCS2303* ll_P1 = new LinkedListCS2303();
	delete ll_P1;
	cout << "Back from first delete" << endl; fflush(stdout);
	ll_P1 = new LinkedListCS2303();
	FileWithAttributes* theFileP = (FileWithAttributes*)malloc(sizeof(FileWithAttributes));
	Payload2* payP1 = (Payload2*) malloc(sizeof(Payload2));
	//payload points to file
	Attributes* theAttributesP = (Attributes*) malloc(sizeof(Attributes));
	//make the payload(pointer to file with attributes) point to the file with attributes
	payP1->fP = theFileP;
	//make the file with attributes point to its attributes
	payP1->fP->setAP(theAttributesP);
	//establish some attributes
	char fname[] = "file2";
	payP1->fP->setFilename(fname);
	payP1->fP->setIsDir(false);
	//make the date and time parts
	FDate* dP = (FDate*)malloc(sizeof(FDate));
	FTime* tP = (FTime*)malloc(sizeof(FTime));
	theAttributesP->dP = dP;
	theAttributesP->tP = tP;
	dP->day = 21;
	dP->month = 9;
	dP->year = 2019;
	tP->hour = 3;
	tP->min=23;
	tP->isAM=false;

	ll_P1->makeSingletonList(payP1);//first list item
	FileWithAttributes* theFileP2 = (FileWithAttributes*)malloc(sizeof(FileWithAttributes));
	Payload2* payP2 = (Payload2*) malloc(sizeof(Payload2));
	Attributes* theAttributesP2 = (Attributes*) malloc(sizeof(Attributes));
	//make the payload(pointer to file with attributes) point to the file with attributes
	payP2->fP = theFileP2;
	//make the file with attributes point to its attributes
	payP2->fP->setAP(theAttributesP2);
	//establish some attributes
	char fname2[] = "file2";
	payP2->fP->setFilename(fname2);
	payP2->fP->setIsDir(false);
	//make the date and time parts
	FDate* dP2 = (FDate*)malloc(sizeof(FDate));
	FTime* tP2 = (FTime*)malloc(sizeof(FTime));
	theAttributesP2->dP = dP2;
	theAttributesP2->tP = tP2;
	dP2->day = 2;
	dP2->month = 2;
	dP2->year = 2019;
	tP2->hour = 3;
	tP2->min=23;
	tP2->isAM=false;
	LLNode* retP = ll_P1->growList(payP2);//second list item, 0 traversals
	cout << "Back from growList with "<<retP << endl; fflush(stdout);
	cout << "Get next is " << ll_P1->getNext() <<endl; fflush(stdout);
	cout << ll_P1->getNext()->payP <<endl; fflush(stdout);

	FileWithAttributes* theFileP3 = (FileWithAttributes*)malloc(sizeof(FileWithAttributes));
	Attributes* theAttributesP3 = (Attributes*) malloc(sizeof(Attributes));
	Payload2* payP3 = (Payload2*) malloc(sizeof(Payload2));
	payP3->fP = theFileP3;
	//make the file with attributes point to its attributes
	payP3->fP->setAP(theAttributesP3);
	FDate* dP3 = (FDate*)malloc(sizeof(FDate));
	FTime* tP3 = (FTime*)malloc(sizeof(FTime));
	theAttributesP3->dP = dP3;
	theAttributesP3->tP = tP3;
	dP3->day = 20;
	dP3->month = 10;
	dP3->year = 2019;

	LLNode* ret2P = ll_P1->growList(payP3);

	delete ll_P1;
	cout << "Back from second delete" << endl; fflush(stdout);
	return ok;
}

bool Tests::testGetFilesFromDirectory()
{
	bool answer = true;
	char filename[FILENAMELENGTH+1];
	for(int i = 0; i<FILENAMELENGTH+1;i++ )
	{
		*(filename+i)='\0';
	}
	cout << "Enter absolute directory name to list, e.g. C:\\Users ";
	cin.getline(filename, 100);

	// Build command to execute.
	// dir directoryname

	string str = "dir ";
	str = str + filename;

	// Convert string to const char * as system requires
	// parameter of type const char *
	const char* command = str.c_str();
	//Checking intermediate result
	printf("The command is %s.\n", command);

	//want to collect the answer somehow
	//system("/bin/ls -l > Result");
	str = str + "> C:\\Users\\Therese\\Documents\\2019Fall\\CS2303\\dirListing.txt";
	const char* command2 = str.c_str();
	system(command2);

	//Can look at the output in the dirListing.txt
	//no automated check



	return answer;

}
bool Tests::testGetFilesFromListingFile()
{
	bool answer = true;
	return answer;


}
bool Tests::testMakeFileWithAttributes()
{
	bool answer = true;
	//make a set of attributes
	//construct a file with those
	Attributes* aP = (Attributes*) malloc(sizeof(Attributes));
	FDate* dP = (FDate*)malloc(sizeof(FDate));
	FTime* tP = (FTime*)malloc(sizeof(FTime));
	aP->dP = dP;
	aP->tP = tP;
	dP->day = 21;
	dP->month = 9;
	dP->year = 2019;
	tP->hour = 3;
	tP->min=23;
	tP->isAM=false;
	FileWithAttributes* fP = new FileWithAttributes(aP);
	//now we have the file, can we get the attributes?

	if(fP->getDay() != 21)
	{
		answer = false;
		cout<<"Day should be 21 but was: "<<fP->getDay()<<endl;
	}
	if(fP->getMonth() != 9)
	{
		answer = false;
		cout<<"Month should be 9 but was: "<<fP->getMonth()<<endl;
	}
	if(fP->getYear() != 2019)
	{
		answer = false;
		cout<<"Year should be 2019 but was: "<<fP->getYear()<<endl;
	}
	if(fP->getHour() != 3)
	{
		answer = false;
		cout<<"Hour should be 3 but was: "<<fP->getHour()<<endl;
	}
	if(fP->getMinute() != 23)
	{
		answer = false;
		cout<<"Minute should be 23 but was: "<<fP->getMinute()<<endl;
	}
	if((fP->getAMPM() ))
	{
		answer = false;
		cout<<"AMPM should be 0 but was: "<<fP->getAMPM()<<endl;
	}


	return answer;


}


bool Tests::testDesignateAttribute()
{
	bool answer = true;
	return answer;

}
bool Tests::testSortOnDesignatedAttribute()
{
	bool answer = true;
	return answer;

}
bool Tests::testIdentifyViewableAttribute()
{
	bool answer = true;
	return answer;

}
bool Tests::testDisplayList()
{
	bool answer = true;
	return answer;

}

bool  Tests::testDisplayFileNamesFromLinkedList()
{
	bool ok = true;
	LinkedListCS2303* ll_P1 = new LinkedListCS2303();
	FileWithAttributes* theFileP = (FileWithAttributes*)malloc(sizeof(FileWithAttributes));
	Payload2* payP1 = (Payload2*) malloc(sizeof(Payload2));
	//payload points to file
	Attributes* theAttributesP = (Attributes*) malloc(sizeof(Attributes));
	//make the payload(pointer to file with attributes) point to the file with attributes
	payP1->fP = theFileP;
	//make the file with attributes point to its attributes
	payP1->fP->setAP(theAttributesP);
	//establish some attributes
	char fname[] = "file1";
	payP1->fP->setFilename(fname);
	payP1->fP->setIsDir(false);
	//make the date and time parts
	FDate* dP = (FDate*)malloc(sizeof(FDate));
	FTime* tP = (FTime*)malloc(sizeof(FTime));
	theAttributesP->dP = dP;
	theAttributesP->tP = tP;
	dP->day = 21;
	dP->month = 9;
	dP->year = 2019;
	tP->hour = 3;
	tP->min=23;
	tP->isAM=false;

	ll_P1->makeSingletonList(payP1);//first list item
	FileWithAttributes* theFileP2 = (FileWithAttributes*)malloc(sizeof(FileWithAttributes));
	Payload2* payP2 = (Payload2*) malloc(sizeof(Payload2));
	Attributes* theAttributesP2 = (Attributes*) malloc(sizeof(Attributes));
	//make the payload(pointer to file with attributes) point to the file with attributes
	payP2->fP = theFileP2;
	//make the file with attributes point to its attributes
	payP2->fP->setAP(theAttributesP2);
	//establish some attributes
	char fname2[] = "file2";
	payP2->fP->setFilename(fname2);
	payP2->fP->setIsDir(false);
	//make the date and time parts
	FDate* dP2 = (FDate*)malloc(sizeof(FDate));
	FTime* tP2 = (FTime*)malloc(sizeof(FTime));
	theAttributesP2->dP = dP2;
	theAttributesP2->tP = tP2;
	dP2->day = 2;
	dP2->month = 2;
	dP2->year = 2019;
	tP2->hour = 3;
	tP2->min=23;
	tP2->isAM=false;
	LLNode* retP = ll_P1->growList(payP2);//second list item, 0 traversals
	cout << "Back from growList with "<<retP << endl; fflush(stdout);
	cout << "Get next is " << ll_P1->getNext() <<endl; fflush(stdout);
	cout << ll_P1->getNext()->payP <<endl; fflush(stdout);

	if(ll_P1->getNext()->payP != payP2)
	{
		ok = false;
	}
	cout << "Back from adding payload" << endl; fflush(stdout);
	if(ll_P1->getNext()->payP->fP->getYear() != 2019)
	{
		cout << "Did not get 2019, got " << ll_P1->getNext()->payP->fP->getYear() <<endl;
		ok = false;
	}
	FileWithAttributes* theFileP3 = (FileWithAttributes*)malloc(sizeof(FileWithAttributes));
	Attributes* theAttributesP3 = (Attributes*) malloc(sizeof(Attributes));
	Payload2* payP3 = (Payload2*) malloc(sizeof(Payload2));
	payP3->fP = theFileP3;
	//make the file with attributes point to its attributes
	payP3->fP->setAP(theAttributesP3);
	char fname3[] = "file3";
	payP3->fP->setFilename(fname3);
	FDate* dP3 = (FDate*)malloc(sizeof(FDate));
	FTime* tP3 = (FTime*)malloc(sizeof(FTime));
	theAttributesP3->dP = dP3;
	theAttributesP3->tP = tP3;
	dP3->day = 20;
	dP3->month = 10;
	dP3->year = 2019;
	LLNode* retP3 = ll_P1->growList(payP3);//third list item
	//lines above make a linked list of three nodes of files.
	//the file names are file1, file2, file3
	//so navigate the list, printing file names as we go.
	LLNode* cursor = ll_P1->getHead();
	cout << "Here are the filenames."<<endl;fflush(stdout);
	while(cursor->next)
	{
		//get this node's name
		cout << cursor->payP->fP->getFilename() << endl;
		//move on to the next
		cursor = cursor->next;
	}
	//now get the last node's filename
	cout << cursor->payP->fP->getFilename() << endl;fflush(stdout);
	return ok;
}
