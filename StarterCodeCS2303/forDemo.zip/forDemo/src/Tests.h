/*
 * Tests.h
 *
 *  Created on: Sep 5, 2019
 *      Author: Therese
 */

#ifndef TESTS_H_
#define TESTS_H_

#define FILENAMELENGTH 200

#include <stdbool.h>
#include <bits/stdc++.h>
using namespace std;

class Tests {
public:
	Tests();
	virtual ~Tests();
	bool tests();
private:
	bool testEmptyList();
	bool testSingletonList();
	bool testAddNode();
	bool testDeleteList();
	bool testGetFilesFromDirectory();
	bool testGetFilesFromListingFile();
	bool testMakeFileWithAttributes();
	bool testDesignateAttribute();
	bool testSortOnDesignatedAttribute();
	bool testIdentifyViewableAttribute();
	bool testDisplayList();
	bool testDisplayFileNamesFromLinkedList();
};

#endif /* TESTS_H_ */
