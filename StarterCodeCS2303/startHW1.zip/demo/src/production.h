/*
 * production.h
 *
 *  Created on: Oct 22, 2019
 *      Author: Therese
 */

#ifndef PRODUCTION_H_
#define PRODUCTION_H_
#include <stdbool.h>

bool production(int argc, char* argv[]);

#endif /* PRODUCTION_H_ */
