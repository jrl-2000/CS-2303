/*
 * test.c
 *
 *  Created on: Oct 22, 2019
 *      Author: Therese
 */
#include "tests.h"

bool tests()
{//this will get changed into a list of tests
	bool ok1 = testTheFirstThing();
	return ok1;
}

bool testTheFirstThing()
{
	bool ans = true;
	// a couple of test cases need to be found here
	//if all test cases pass, then ans will be true
	//otherwise it will be false
	return ans;
}
