/*
 * test.h
 *
 *  Created on: Oct 22, 2019
 *      Author: Therese
 */

#ifndef TESTS_H_
#define TESTS_H_

#include <stdbool.h>
bool tests();
bool testTheFirstThing();

#endif /* TESTS_H_ */
