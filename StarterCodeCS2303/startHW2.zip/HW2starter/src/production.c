/*
 * production.c
 *
 *  Created on: Jul 4, 2019
 *      Author: Therese
 */
#include "production.h"
bool production(int argc, char* argv[])
{
	bool answer = false;

		if(argc <=1) //no interesting information
		{
			puts("Didn't find any arguments.");
			fflush(stdout);
			answer = false;
		}
		else //there is interesting information
		{
			printf("Found %d arguments.\n", argc);
			fflush(stdout);
			char filename[FILENAMELENGTHALLOWANCE];
			char* eptr=(char*) malloc(sizeof(char*));
			long aL=-1L;
			int a;
			for(int i = 1; i<argc; i++) //don't want to read argv[0]
			{//argv[i] is a string
				//in this program our arguments are NR, NC, gens, filename, print and pause
				//because pause is optional, argc could be 6 or 7
				//because print is optional (if print is not present, neither is pause) argc could be 5
				switch(i)
				{
				case 1:
					//this is filename
					printf("The length of the filename is %d.\n",strlen(argv[i]));
					printf("The proposed filename is %s.\n", argv[i]);
					if(strlen(argv[i])>=FILENAMELENGTHALLOWANCE)
					{
						puts("Filename is too long.");
						fflush(stdout);
						answer = false;
					}
					else
					{
						strcpy(filename, argv[i]);
						printf("Filename was %s.\n", filename);
						fflush(stdout);
					}
					break;
				case 2:
					//this is maximum number of turns

					aL= strtol(argv[i], &eptr, 10);
					a = (int) aL;
	                printf("Number of turns is %d\n",a);
					break;

				default:
					puts("Unexpected argument count.");
					fflush(stdout);
					answer = false;
					break;
				}
			}
		}
	    //we'll want to read the file and set up the board
		//we'll want to enqueue the moves


		return answer;

	showBoard();

	return answer;
}
void showBoard()
{


}
