/*
 * tests.c
 *
 *  Created on: Jul 4, 2019
 *      Author: Therese
 */

#include "tests.h"
#include "production.h"


bool tests()
{
	bool answer = false;
	bool ok1 =  testReadFile();
	bool ok2 = testSomething();
	bool ok3 = testSomethingElse();
	answer = ok1 && ok2 && ok3;
	return answer;
}

bool testReadFile()
{
	puts("starting testReadFile");
	fflush(stdout);
	bool ok = false;
	//the file tells how many rooms there are
	//the right answer is 6
	int nrooms = -1;//initialize, silly value

	AdjMat* adjMP = (AdjMat*) malloc(sizeof(AdjMat));
	Treas* treasP = (Treas*) malloc(6*sizeof(Treas));

	ok = readFile("houseGraph.txt", &nrooms, adjMP, treasP); //read the file
	if(ok)
	{
		if(nrooms!=6)
		{
			puts("test failed on nrooms");
		}

	}


	return ok;
}

bool testSomething()
{
	bool ans = false;

	return ans;
}

bool testSomethingElse()
{
	bool ans = false;

	return ans;
}
